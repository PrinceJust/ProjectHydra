import styled from 'styled-components';
import {ActionButtonsProps, ActionButtonCssProps, ActionButtonSizeCssProps} from './index.interfaces'

const ActionbuttonCss:ActionButtonCssProps = {
  default: {
    color: '#4D96D1',
    backgroundColor: '#fff',
    borderColor: '#4D96D1',
    hover: {
      backgroundColor: '#4D96D1',
      borderColor: '#4D96D1',
      color: '#fff',
    } 
  },
  info: {
    color: '#fff',
    backgroundColor: '#4D96D1',
    borderColor: '#4D96D1',
    hover: {
      backgroundColor: '#1F64B1',
      borderColor: '#1F64B1', 
    }
  },
  warning: {
    color: '#fff',
    backgroundColor: '#FFCD4E',
    borderColor: '#FFCD4E',
    hover: {
      backgroundColor: '#EFB215',
      borderColor: '#EFB215',
    }
  },
  danger: {
    color: '#fff',
    backgroundColor: '#F7675D',
    borderColor: '#F7675D',
    hover: {
      backgroundColor: '#DA3025',
      borderColor: '#DA3025',
    }
  }
}

const ActionbuttonSizeCss:ActionButtonSizeCssProps = {
  sm: {
    padding: '8px 20px 6px',
    fontSize: '14px',
    lineHeight: '19px',
    borderRadius: '4px'
  },
  md: {
    padding: '11px 30px 10px',
    fontSize: '14px',
    lineHeight: '19px',
    borderRadius: '4px'
  },
  lg: {
    padding: '12px 40px',
    fontSize: '16px',
    lineHeight: '22px',
    borderRadius: '4px'
  },
  
}

export const StyledActionButton = styled.button<ActionButtonsProps>`
  color: ${({ variant = 'default' }) => ActionbuttonCss[variant].color};
  background-color: ${({ variant = 'default' }) => ActionbuttonCss[variant].backgroundColor};
  border: 1px solid ${({ variant = 'default' }) => ActionbuttonCss[variant].borderColor};
  cursor: pointer;
  transition: 0.5s all ease;
  &:hover {
    &:not([disabled]) {
      background-color: ${({ variant = 'default' }) => ActionbuttonCss[variant].hover.backgroundColor};
      border: 1px solid ${({ variant = 'default' }) => ActionbuttonCss[variant].hover.borderColor};
    }
    transition: 0.5s all ease;
    color: ${({ variant = 'default' }) => ActionbuttonCss[variant].hover.color}
  }
  &:disabled {
    background-color: #DADADA;
    color: #aaa;
    cursor: default;
    border: 1px solid #dadada;
  }
  padding: ${({ sizes = 'md' }) => ActionbuttonSizeCss[sizes].padding};
  font-size: ${({ sizes = 'md' }) => ActionbuttonSizeCss[sizes].fontSize};
  border-radius: ${({ sizes = 'md' }) => ActionbuttonSizeCss[sizes].borderRadius};
  line-height: ${({ sizes = 'md' }) => ActionbuttonSizeCss[sizes].lineHeight};
  margin: 0 3px;
  box-shadow: none;
  font-family: 'Open Sans', sans-serif;
`