import React from 'react'

export interface ActionButtonsProps extends React.HTMLProps<HTMLButtonElement> {
  variant? : 'default' | 'info' | 'warning' | 'danger',
  text? : string,
  sizes? : 'sm' | 'md' | 'lg',
  disabled? : boolean,
  click?() : void
}

export interface VariantCssProps {
  color: string,
  backgroundColor: string,
  borderColor: string,
  hover: {
    backgroundColor: string,
    borderColor: string,
    color?: string, 
  }
}

export interface ActionButtonCssProps {
  default: VariantCssProps,
  info: VariantCssProps,
  warning: VariantCssProps,
  danger: VariantCssProps
}

export interface ActionButtonSizeCssProps {
  sm: SizeCssProps,
  md: SizeCssProps,
  lg: SizeCssProps
}

export interface SizeCssProps {
  padding: string,
  fontSize: string,
  borderRadius: string,
  lineHeight: string
}